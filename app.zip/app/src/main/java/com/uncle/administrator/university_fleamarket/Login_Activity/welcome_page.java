package com.uncle.administrator.university_fleamarket.Login_Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.EditText;
import android.widget.TextView;

import com.uncle.administrator.university_fleamarket.MainActivity;
import com.uncle.administrator.university_fleamarket.R;

/**
 * Created by Administrator on 2017/4/15 0015.
 */

public class welcome_page extends Activity {
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);
        init();
    }

    private void init() {
        tv = (TextView) findViewById(R.id.welcome_tv);
        new Thread() {
            @Override
            public void run() {
                super.run();
                for (int i = 3; i >= 0; i--) {
                    String time = String.valueOf(i);

                    Message message = new Message();
                    message.what = 1;
                    message.obj = time;
                    handler.sendMessage(message);


                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.start();
    }

    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 1:
                    String time = (String) msg.obj;
                    tv.setText(time);
                    if (time.equals("0")) {
                        SharedPreferences sharedPreferences = getSharedPreferences("account", Context.MODE_PRIVATE);
                        String account = sharedPreferences.getString("account", "");
                        if (account.equals(null) || account.length() <= 0) {
                            Intent intent = new Intent(welcome_page.this, Login_activity_1.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Intent intent = new Intent(welcome_page.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                    break;
            }


        }
    };
}