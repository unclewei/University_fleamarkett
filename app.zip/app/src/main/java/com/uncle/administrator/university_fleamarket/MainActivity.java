package com.uncle.administrator.university_fleamarket;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;


import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import cn.bmob.v3.Bmob;

public class MainActivity extends FragmentActivity implements View.OnClickListener {

    // 三个tab布局
    private RelativeLayout knowLayout, iWantKnowLayout, meLayout;

    // 底部标签切换的Fragment
    private Fragment the_first; private Fragment the_secend; private Fragment the_thirs;
            private Fragment currentFragment;
    // 底部标签图片
    private ImageView knowImg, iWantKnowImg, meImg;
    // 底部标签的文本
    private TextView knowTv, iWantKnowTv, meTv;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_fragment);


        initUI();
        initTab();
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

    }

    /**
     * 初始化UI
     */
    private void initUI() {
        knowLayout = (RelativeLayout) findViewById(R.id.rl_know);
        iWantKnowLayout = (RelativeLayout) findViewById(R.id.rl_want_know);
        meLayout = (RelativeLayout) findViewById(R.id.rl_me);
        knowLayout.setOnClickListener(this);
        iWantKnowLayout.setOnClickListener(this);
        meLayout.setOnClickListener(this);

        knowImg = (ImageView) findViewById(R.id.iv_know);
        iWantKnowImg = (ImageView) findViewById(R.id.iv_i_want_know);
        meImg = (ImageView) findViewById(R.id.iv_me);
        knowTv = (TextView) findViewById(R.id.tv_know);
        iWantKnowTv = (TextView) findViewById(R.id.tv_i_want_know);
        meTv = (TextView) findViewById(R.id.tv_me);

    }

    /**
     * 初始化底部标签
     */
    private void initTab() {

        if (the_first == null) {
            the_first = new the_base_button_1();
        }

        if (!the_first.isAdded()) {
            // 提交事务
            getSupportFragmentManager().beginTransaction().add(R.id.content_layout,the_first).commit();

            // 记录当前Fragment
            currentFragment = the_first;
            // 设置图片文本的变化
            knowImg.setImageResource(R.drawable.shopping);
            knowTv.setTextColor(getResources()
                    .getColor(R.color.common_plus_signin_btn_text_light));
            iWantKnowImg.setImageResource(R.drawable.talk);
            iWantKnowTv.setTextColor(getResources().getColor(
                    R.color.common_google_signin_btn_text_dark));
            meImg.setImageResource(R.drawable.head_black);
            meTv.setTextColor(getResources().getColor(R.color.common_action_bar_splitter));

        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.rl_know: // 知道
                clickTab1Layout();
                break;
            case R.id.rl_want_know: // 我想知道
                clickTab2Layout();
                break;
            case R.id.rl_me: // 我的
                clickTab3Layout();
                break;
            default:
                break;
        }
    }//各个点击事件

    /**
     * 点击第一个tab
     */
    private void clickTab1Layout() {

        if (the_first == null) {
            the_first = new the_base_button_1();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), the_first);

        // 设置底部tab变化
        knowImg.setImageResource(R.drawable.common_google_signin_btn_icon_dark);
        knowTv.setTextColor(getResources()
                .getColor(R.color.common_plus_signin_btn_text_light));
        iWantKnowImg.setImageResource(R.drawable.talk);
        iWantKnowTv.setTextColor(getResources().getColor(
                R.color.common_google_signin_btn_text_dark));
        meImg.setImageResource(R.drawable.head_black);
        meTv.setTextColor(getResources().getColor(R.color.common_action_bar_splitter));

    }

    /**
     * 点击第二个tab
     */
    private void clickTab2Layout() {
        if (the_secend == null) {
            the_secend = new the_base_button_2();
        }
        addOrShowFragment(getSupportFragmentManager().beginTransaction(), the_secend);

        knowImg.setImageResource(R.drawable.shopping);
        knowTv.setTextColor(getResources()
                .getColor(R.color.common_plus_signin_btn_text_light));
        iWantKnowImg.setImageResource(R.drawable.common_google_signin_btn_icon_dark);
        iWantKnowTv.setTextColor(getResources().getColor(
                R.color.common_google_signin_btn_text_dark));
        meImg.setImageResource(R.drawable.head_black);
        meTv.setTextColor(getResources().getColor(R.color.common_action_bar_splitter));

    }

    /**
     * 点击第三个tab
     */
    private void clickTab3Layout() {
        if (the_thirs == null) {
            the_thirs = new the_base_button_3();
        }

        addOrShowFragment(getSupportFragmentManager().beginTransaction(), the_thirs);
        knowImg.setImageResource(R.drawable.shopping);
        knowTv.setTextColor(getResources()
                .getColor(R.color.common_plus_signin_btn_text_light));
        iWantKnowImg.setImageResource(R.drawable.talk);
        iWantKnowTv.setTextColor(getResources().getColor(
                R.color.common_google_signin_btn_text_dark));
        meImg.setImageResource(R.drawable.head_yard);
        meTv.setTextColor(getResources().getColor(R.color.common_action_bar_splitter));

    }

    /**
     * 添加或者显示碎片
     *
     * @param transaction
     * @param fragment
     */
    private void addOrShowFragment(FragmentTransaction transaction, Fragment fragment) {
        if (currentFragment == fragment)
            return;

        if (!fragment.isAdded()) { // 如果当前fragment未被添加，则添加到Fragment管理器中
            transaction.hide(currentFragment)
                    .add(R.id.content_layout, fragment).commit();
        } else {
            transaction.hide(currentFragment).show(fragment).commit();
        }

        currentFragment = fragment;
    }



}
