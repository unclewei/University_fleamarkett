package com.uncle.administrator.university_fleamarket.Login_Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.uncle.administrator.university_fleamarket.MainActivity;
import com.uncle.administrator.university_fleamarket.R;
import com.uncle.bomb.BOMB_openhelper;

import java.util.ArrayList;
import java.util.HashMap;

import cn.bmob.sms.BmobSMS;
import cn.bmob.sms.exception.BmobException;
import cn.bmob.sms.listener.RequestSMSCodeListener;
import cn.bmob.sms.listener.VerifySMSCodeListener;
import cn.bmob.v3.Bmob;


/**
 * Created by Administrator on 2017/4/15 0015.
 */

public class Login_activity_2 extends Activity {

    private Button send_sms,next;
    private EditText phone_nub,verification;
    private String nub;
    private BOMB_openhelper bomb_openhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity2);
        init();
    }

    private void init() {
        send_sms = (Button) findViewById(R.id.login_activity2_bt_send_sms);
        next = (Button) findViewById(R.id.login_activity2_bt_next);
        phone_nub = (EditText) findViewById(R.id.login_activity2_et_phone_nub);
        verification = (EditText) findViewById(R.id.login_activity2_et_verification);
        bomb_openhelper = new BOMB_openhelper();
        BmobSMS.initialize(Login_activity_2.this,"144dbb1fbca09ce5d3af201a05c54628");
        Bmob.initialize(Login_activity_2.this,"144dbb1fbca09ce5d3af201a05c54628");
        send_sms_onclick();
        bt_next_click();
    }

    public void send_sms_onclick(){
        send_sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 nub = phone_nub.getText().toString().trim();

               if (nub.length() == 0){
                   Toast.makeText(Login_activity_2.this,"电话号码不能为空",Toast.LENGTH_SHORT).show();
               }else if (nub.length() !=11 ){
                   Toast.makeText(Login_activity_2.this,"电话号码长度不对",Toast.LENGTH_SHORT).show();
               }else {
                   send_sms.setClickable(false);
                   send_sms.setTextColor(111111);

                   //发送号码到后台并判断返回验证码
                   BmobSMS.requestSMSCode(Login_activity_2.this, nub, "登录注册验证码",new RequestSMSCodeListener() {

                       @Override
                       public void done(Integer smsId,BmobException ex) {
                           // TODO Auto-generated method stub
                           if(ex==null){//验证码发送成功
                               Log.i("bmob", "短信id："+smsId);//用于查询本次短信发送详情
                               new Thread(){
                                   @Override
                                   public void run() {//创造一个新线程，把button的点击事件设置为不可点击，并倒数60s
                                       super.run();
                                       for (int i = 60 ;i >=0 ;i--) {

                                           String time = String.valueOf(i);
                                           Message message = new Message();
                                           message.what = 1;
                                           message.obj = time;
                                           handler.sendMessage(message);
                                           try {
                                               Thread.sleep(1000);
                                           } catch (InterruptedException e) {
                                               e.printStackTrace();
                                           }

                                       }
                                   }
                               }.start();
                           }
                       }
                   });
               }
            }
        });
    }
    public void bt_next_click(){
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String verification_nub = verification.getText().toString().trim();
                if (verification_nub.length() == 0) {
                    Toast.makeText(Login_activity_2.this, "验证码不能为空", Toast.LENGTH_SHORT).show();
                }else {
                    //判断验证码正确与否，如果正确，就转入程序并把账号密码存入shareperference里面
                    //再初始化人名，获取账号的objectid

                    BmobSMS.verifySmsCode(Login_activity_2.this,nub, verification_nub, new VerifySMSCodeListener() {

                        @Override
                        public void done(BmobException ex) {
                            // TODO Auto-generated method stub
                            if(ex==null){//短信验证码已验证成功
                                Log.i("bmob", "验证通过");
                                bomb_openhelper.find_account(nub, new BOMB_openhelper.Find_account_callback() {
                                    @Override
                                    public void onSuccess(ArrayList<HashMap<String, String>> arrayList) {//在数据库中已经有账号的，直接获取数据登录跳转
                                        HashMap<String ,String > hashMap = arrayList.get(0);
                                        SharedPreferences sharedPreferences = getSharedPreferences("account", Context.MODE_WORLD_READABLE);
                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        editor.putString("account", nub);
                                        editor.putString("object_id", hashMap.get("object_id"));
                                        editor.putString("nick_name", hashMap.get("nick_name"));
                                        editor.putString("head_portrait",hashMap.get("head_portrait"));
                                        editor.commit();
                                        Intent intent = new Intent(Login_activity_2.this,MainActivity.class);
                                        startActivity (intent );
                                        finish();
                                    }
                                    @Override
                                    public void onFail(int fail_code) {//在数据库中找不到账号的，创建新的账号，并且登录跳转
                                    if (fail_code == 9015){
                                        bomb_openhelper.add_account("无名氏",null,nub, new BOMB_openhelper.Add_account_callback() {
                                            @Override
                                            public void onSuccess(String object) {
                                                String objextId =object;
                                                SharedPreferences sharedPreferences = getSharedPreferences("account", Context.MODE_WORLD_READABLE);
                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                editor.putString("account", nub);
                                                editor.putString("object_id", objextId);
                                                editor.putString("nick_name", "无名氏");
                                                editor.putString("head_portrait_adress",null);

                                                editor.commit();
                                                Intent intent = new Intent(Login_activity_2.this,MainActivity.class);
                                                startActivity (intent );
                                                finish();
                                            }
                                        });

                                    }
                                    }
                                });

                            }else{
                                Log.i("bmob", "验证失败：code ="+ex.getErrorCode()+",msg = "+ex.getLocalizedMessage());
                                if (ex.getErrorCode() == 207) {
                                    Toast.makeText(Login_activity_2.this, "验证码错误", Toast.LENGTH_SHORT).show();
                                }else {
                                    Toast.makeText(Login_activity_2.this, "验证失败", Toast.LENGTH_SHORT).show();

                                }

                            }
                        }
                    });
                }

            }
        });
    }




    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 1:
                    String time = (String) msg.obj;
                    send_sms.setText("发送成功" +"("+time+")");
                    if (time.equals("0")){
                        send_sms.setClickable(true);
                        send_sms.setTextColor(000000);
                        send_sms.setText("发送");
                    }
                    break;
            }


        }
    };

}
