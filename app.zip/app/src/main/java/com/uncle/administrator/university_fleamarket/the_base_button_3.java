package com.uncle.administrator.university_fleamarket;



import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.uncle.bomb.BOMB_openhelper;
import com.uncle.database.Chat_data_Dao;
import com.uncle.database.goods_Dao;
import com.uncle.database.goods_SQL_OpenHelper;

/**
 * Created by Administrator on 2016/11/22 0022.
 */

public class the_base_button_3 extends Fragment {
    private LinearLayout sell ,clean;
    private TextView tv_name;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        return inflater.inflate(R.layout.the_base_button_3, null);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        init();
        sell();

    }
    public void init(){
        clean = (LinearLayout) getActivity().findViewById(R.id.clean);
        sell = (LinearLayout) getActivity().findViewById(R.id.bt3_sell);
        tv_name = (TextView) getActivity().findViewById(R.id.the_base_button_3_name);


        get_name();
    }

    private void get_name(){
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("account", Context.MODE_PRIVATE);
        String name = sharedPreferences.getString("nick_name", null);
        tv_name.setText(name);
    }
    public void sell(){
        sell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(),sell.class);
                startActivity(intent);
            }
        });
        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                Chat_data_Dao dao = new Chat_data_Dao(getContext());
//                dao.delete();
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("account", Context.MODE_WORLD_READABLE);
                SharedPreferences.Editor editor =sharedPreferences.edit();
                editor.clear();
                editor.commit();
//                goods_SQL_OpenHelper helper = new goods_SQL_OpenHelper(getContext());//开启数据库
//                helper.getWritableDatabase();
//                goods_Dao dao = new goods_Dao(getContext());
//                dao.delete();
                Toast.makeText(getContext(),"clean",Toast.LENGTH_SHORT ).show();
            }
        });
    }
}
