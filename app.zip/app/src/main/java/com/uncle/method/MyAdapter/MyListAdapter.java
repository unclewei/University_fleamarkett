package com.uncle.method.MyAdapter;

/**
 * Created by Administrator on 2017/2/9 0009.
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.uncle.administrator.university_fleamarket.R;

public class MyListAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private ListView listView;
    private AsyncImageLoader asyncImageLoader;

    private List<HashMap<String,String>> dataArray=new ArrayList<>();

    public MyListAdapter(Activity activity, List<HashMap<String,String>> imageAndTexts, ListView listView) {

        this.listView = listView;
        asyncImageLoader = new AsyncImageLoader();
        inflater = activity.getLayoutInflater();
        dataArray=imageAndTexts;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return dataArray.size();
    }
    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        if(position >= getCount()){
            return null;
        }
        return dataArray.get(position);
    }
    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }


    //不需要ViewHolder版，直接将ImageAndText与XML资源关联起来
    public View getView( int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.adapter_base, null);
        }else{
            convertView.setTag(position);
        }

        System.out.println("position的数字是："+position);
        HashMap<String,String> imageAndText = (HashMap<String,String>) getItem(position);
        String imageUrl1 = imageAndText.get("image1");
        String imageUrl2 = imageAndText.get("image2");
        String imageUrl3 = imageAndText.get("image3");

        TextView title =  (TextView) convertView.findViewById(R.id.adapter_title);
        TextView price =  (TextView) convertView.findViewById(R.id.adapter_price);
        TextView zan = (TextView) convertView.findViewById(R.id.adapter_base_zan);
        // 将XML视图项与用户输入的URL和文本在绑定
        title.setText(imageAndText.get("title"));//加载title
        price.setText(imageAndText.get("price"));//加载price
        zan.setText(imageAndText.get("zan_nub"));//加载赞的数量zan

        ImageView iv1 = (ImageView) convertView.findViewById(R.id.adapter_img1);
        ImageView iv2 = (ImageView) convertView.findViewById(R.id.adapter_img2);
        ImageView iv3 = (ImageView) convertView.findViewById(R.id.adapter_img3);
        iv1.setBackgroundResource(R.drawable.img_loading);//在初始化时，先把背景图片设置成默认背景，
        iv2.setBackgroundResource(R.drawable.img_loading);//在初始化时，先把背景图片设置成默认背景，
        iv3.setBackgroundResource(R.drawable.img_loading);//在初始化时，先把背景图片设置成默认背景，
        //否则在下拉时会随机匹配背景，不美观

        asyncImageLoader.loadDrawable(inflater.getContext(),position,imageUrl1, new AsyncImageLoader.ImageCallback() {
            @Override
            public void onImageLoad(Integer pos, Drawable drawable) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img1);
                    iv.setBackgroundDrawable(drawable);

                }

           }
            //加载不成功的图片处理
            @Override
            public void onError(Integer pos) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img1);
                    iv.setBackgroundResource(R.drawable.c);
//                    System.out.println("111111111111111111111111111111111：");
                }
            }

        });
        asyncImageLoader.loadDrawable(inflater.getContext(),position,imageUrl2, new AsyncImageLoader.ImageCallback() {
            @Override
            public void onImageLoad(Integer pos, Drawable drawable) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img2);
                    iv.setBackgroundDrawable(drawable);
                }
            }
            //加载不成功的图片处理
            @Override
            public void onError(Integer pos) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img2);
                    iv.setBackgroundResource(R.drawable.c);
                }
            }

        });
        asyncImageLoader.loadDrawable(inflater.getContext(),position,imageUrl3, new AsyncImageLoader.ImageCallback() {
            @Override
            public void onImageLoad(Integer pos, Drawable drawable) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img3);
                    iv.setBackgroundDrawable(drawable);
                }
            }
            //加载不成功的图片处理
            @Override
            public void onError(Integer pos) {
                View view = listView.findViewWithTag(pos);
                if(view != null){
                    ImageView iv = (ImageView) view.findViewById(R.id.adapter_img3);
                    iv.setBackgroundResource(R.drawable.c);
                }
            }

        });

        position++;
        return convertView;
    }
}