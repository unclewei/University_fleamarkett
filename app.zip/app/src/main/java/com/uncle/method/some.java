package com.uncle.method;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Administrator on 2017/1/17 0017.
 */

public class some {
    public void ShowToast(Context c, String a){
        Toast.makeText(c,a,Toast.LENGTH_SHORT).show();
    }
}
