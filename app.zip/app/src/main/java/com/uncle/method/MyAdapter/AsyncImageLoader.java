package com.uncle.method.MyAdapter;

/**
 * Created by Administrator on 2017/2/10 0010.
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.HashMap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;

public class AsyncImageLoader {
    final Handler handler = new Handler();
    private int i = 0;
    private HashMap<String, SoftReference<Drawable>> imageCache;
    public AsyncImageLoader() {
        imageCache = new HashMap<String, SoftReference<Drawable>>();//图片缓存
    }

    // 回调函数
    public interface ImageCallback {
        public void onImageLoad(Integer t, Drawable drawable);
        public void onError(Integer t);
    }

    public Drawable loadDrawable(final Context c,final Integer pos, final String imageUrl,final ImageCallback imageCallback) {

        new Thread() {
            @Override
            public void run() {
                   LoadImg(c,pos, imageUrl, imageCallback);
            }
        }.start();
        return null;
    }// loadDrawable---end

    public void LoadImg(final Context c,final Integer pos, final String imageUrl,
                        final ImageCallback imageCallback) {
        // 首先判断是否在缓存中
        // 但有个问题是：ImageCache可能会越来越大，以至用户内存用光，所以要用SoftReference（弱引用）来实现
        if (imageCache.containsKey(imageUrl)) {
            SoftReference<Drawable> softReference = imageCache.get(imageUrl);
            final Drawable drawable = softReference.get();

            if (drawable != null) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        imageCallback.onImageLoad(pos, drawable);
                    }
                });
                return;
            }
        }


        // 尝试从URL中加载
        try {
            final Drawable drawable = loadImageFromUrl(c,imageUrl);
            System.out.println("缓冲图片经过这里的次数是：："+i);
            if (drawable != null) {
                imageCache.put(imageUrl, new SoftReference<Drawable>(drawable));
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    imageCallback.onImageLoad(pos, drawable);
                }
            }
            );
        } catch (IOException e) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    imageCallback.onError(pos);
                }
            });
            e.printStackTrace();
        }
    }
    // 根据URL加载图片,如果出现错误throws IOException式的错误，以便在LoadImg中捕获，执行OnError（）函数
    public Drawable loadImageFromUrl(Context c,String url) throws IOException {
        Drawable drawable = loadImageFromNetwork(c,url);
        return drawable;


    }

    // 如果缓存里面有就从缓存获取，否则网络获取图片，返回Drawable对象
    public static Drawable loadImageFromNetwork(Context context, String imageUrl)
    {
        Drawable drawable = null;
        if(imageUrl == null )
            return null;
        String imagePath = "";
        String   fileName   = "";

        // 获取url中图片的文件名与后缀
        if(imageUrl!=null&&imageUrl.length()!=0){
            fileName  = imageUrl.substring(imageUrl.lastIndexOf("/")+1);
        }

        // 图片在手机本地的存放路径,注意：fileName为空的情况
        imagePath = context.getCacheDir() + "/" + fileName;

        Log.i("test","imagePath = " + imagePath);
        File file = new File(context.getCacheDir(),fileName);// 保存文件
        Log.i("test","file.toString()=" + file.toString());
        if(!file.exists()&&!file.isDirectory())
        {
            try {
                // 可以在这里通过文件名来判断，是否本地有此图片

                FileOutputStream fos=new   FileOutputStream( file );
                InputStream is = new URL(imageUrl).openStream();
                int   data = is.read();
                while(data!=-1){
                    fos.write(data);
                    data=is.read();;
                }
                fos.close();
                is.close();
//				drawable = Drawable.createFromStream(
//						new URL(imageUrl).openStream(), file.toString() ); // (InputStream) new URL(imageUrl).getContent();
                drawable = Drawable.createFromPath(file.toString());
                Log.i("test", "file.exists()不文件存在，网上下载:" + drawable.toString());
            } catch (IOException e) {
                Log.d("test", e.getMessage());
            }
        }else
        {
            drawable = Drawable.createFromPath(file.toString());
            Log.i("test", "file.exists()文件存在，本地获取");
        }

        if (drawable == null) {
            Log.d("test", "null drawable");
        } else {
            Log.d("test", "not null drawable");
        }

        return drawable ;
    }
}