package com.uncle.bomb;

import cn.bmob.v3.BmobObject;

/**
 * Created by Administrator on 2017/4/15 0015.
 */

public class User_account extends BmobObject {

    String account;
    String head_portrait;
    String nick_name;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getHead_portrait() {
        return head_portrait;
    }

    public void setHead_portrait(String head_portrait) {
        this.head_portrait = head_portrait;
    }

    public String getNick_name() {
        return nick_name;
    }

    public void setNick_name(String nick_name) {
        this.nick_name = nick_name;
    }
}
