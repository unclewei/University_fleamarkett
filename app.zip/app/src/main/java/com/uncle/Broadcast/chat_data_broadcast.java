package com.uncle.Broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Administrator on 2017/4/25 0025.
 */

public class chat_data_broadcast  extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

    }
}
